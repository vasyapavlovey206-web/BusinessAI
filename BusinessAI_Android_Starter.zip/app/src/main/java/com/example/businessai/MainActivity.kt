package com.example.businessai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BusinessAIApp() }
    }
}

@Composable
fun BusinessAIApp() {
    var business by remember { mutableStateOf("") }
    var request by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Business AI") }) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(20.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    "Створюй рекламу за секунди",
                    style = MaterialTheme.typography.headlineSmall
                )

                OutlinedTextField(
                    value = business,
                    onValueChange = { business = it },
                    label = { Text("Ваш бізнес") },
                    placeholder = { Text("Наприклад: барбершоп") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = request,
                    onValueChange = { request = it },
                    label = { Text("Що потрібно створити?") },
                    placeholder = { Text("Наприклад: пост про знижку 20%") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )

                Button(
                    onClick = {
                        result = if (business.isBlank() || request.isBlank()) {
                            "Заповни обидва поля."
                        } else {
                            "Приклад результату для $business:\n\n" +
                            "🔥 Спеціальна пропозиція!\n\n" +
                            "$request\n\n" +
                            "Не пропусти можливість скористатися пропозицією. " +
                            "Напиши нам прямо зараз, щоб дізнатися деталі!"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Створити")
                }

                if (result.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            result,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }

                Text(
                    "Версія 1.0 • AI генератор текстів для бізнесу",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
